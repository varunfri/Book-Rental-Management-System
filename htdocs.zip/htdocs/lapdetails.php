<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard</title>
    
</head>

<body class="body">

<style>
*{
    margin: 0;
    padding: 0;

}

body{
    background: url("images/lapbg.jpg");
    width: 100%;
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    height: 100vh;
}

.navbar{
    width: 1200px;
    height: 75px;
    margin: auto;
}

.icon{
    width:200px;
    float: left;
    height : 70px;
}

.logo{
    border-radius:10px;
    background: linear-gradient(to top, rgb(255 255 255 / 60%) 50%,rgb(255 255 255 / 60%) 50%);
    margin-top:20px;
    color: #ff7200;
    font-size: 35px;
    font-family: "sans-serif";
    padding: 10px;
    float:left;
    padding-top: 10px;

}
.menu{
    width: 400px;
    float: left;
    height: 70px;

}

ul{
    float: left;
    display: flex;
    justify-content: center;
    align-items: center;
}

ul li{
    list-style: none;
    margin-left: 62px;
    margin-top: 27px;
    font-size: 14px;

}

ul li a{
    text-decoration: none;
    color: black;
    font-family: Arial;
    font-weight: bold;
    transition: 0.4s ease-in-out;

}

ul li a:hover{
    color:orange;

}
.box{
    margin-bottom:30px;
    position:center;
    top: 50%;
    left: 50%;
    padding: 20px;
    box-sizing: border-box;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,.5);
    background: linear-gradient(to top, rgba(255, 251, 251, 0.8)50%,rgba(250, 246, 246, 0.8)50%);
    display: flex;
    align-content: center;
    width: 600px;
    height: 220px;
    margin-top: 80px;
    margin-left: 600px;
}

.box .imgBx{
    width: 150px;
    flex:0 0 150px;
}

.box .imgBx img{
    max-width:140%;
}

.box .content{
    padding-left: 150px;
    height: 100px;
}

.box .button{
    width: 150px;
    height: 50px;
    background: #ff7200;
    border:none;
    margin-top: 30px;
    /* margin-left: 100; */
    font-size: 18px;
    border-radius: 10px;
    cursor: pointer;
    color:#fff;
    transition: 0.4s ease;
}

.utton{
    width: 240px;
    height: 40px;
   
    background: #ff7200;
    border:none;
    font-size: 18px;
    border-radius: 10px;
    cursor: pointer;
    color:#fff;
    transition: 0.4s ease;
}

.de{
    float: left;
    clear: left;
    display: block;

}


.de li a:hover{
    color:black;

}
.de .lis:hover{
    color: white;
}


.nn{
    width:100px;
    /* background: #ff7200; */
    border:none;
    height: 40px;
    font-size: 18px;
    border-radius: 10px;
    cursor: pointer;
    color:white;
    transition: 0.4s ease;

}


.nn a{
    text-decoration: none;
    color: black;
    font-weight: bold;
    
}

.overview{
    text-align: center;
    margin-top: 40px;
    margin-left:400px;
    width:450px;
    border-radius:10px;
    background: linear-gradient(to top, rgb(255 255 255 / 60%) 50%,rgb(255 255 255 / 60%) 50%);
}

.circle{
    border-radius:48%;
    width:65px;
}

.phello{
    width: 200px;
    margin-left: -50px;
    padding: 0px;
}

#stat{
    margin-left: -8px;
}

</style>

<?php 
    require_once('connection.php');
        session_start();

    $value = $_SESSION['email'];
    $_SESSION['email'] = $value;
    
    $sql="select * from users where EMAIL='$value'";
    $name = mysqli_query($con,$sql);
    $rows=mysqli_fetch_assoc($name);
    $sql2="select *from laptops where AVAILABLE='Y'";
    $laptops= mysqli_query($con,$sql2);

    ?>

</script>
  <div class="cd">
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">LAPTOPS</h2>
            </div>
            <div class="menu">
               
                <ul>
                    <li><a href="lapdetails.php">HOME</a></li>
                    <li><a href="contactus2.html">CONTACT</a></li>
                    <li><button class="nn"><a href="index.php">LOGOUT</a></button></li>
                    <li><img src="images/profile.png" class="circle" alt="Alps"></li>
                    <li><p class="phello">HELLO! &nbsp;<a id="pname"><?php echo $rows['FNAME']." ".$rows['LNAME']?></a></p></li>
                    <li><a id="stat" href="bookinstatus.php">BOOKING STATUS</a></li>
                </ul>
            </div>
            
            
        </div>
      <div><h1 class="overview">OUR LAPTOPS OVERVIEW</h1>

    <ul class="de">
    <?php
        while($result= mysqli_fetch_array($laptops))
        {
            //echo $result['LAP_ID'];
            //echo $result['AVAILABLE'];
        
    ?>    
    
    <li>
    <form method="POST">
    <div class="box">
       <div class="imgBx">
            <img src="images/<?php echo $result['LAP_IMG']?>">
        </div>
        <div class="content">
            <?php $res=$result['LAP_ID'];?>
            <h1><?php echo $result['LAP_NAME']?></h1>
            <h2>COMPANY : <a><?php echo $result['COMPANY']?></a> </h2>
            <h2>RAM SIZE : <a><?php echo $result['RAM']?></a> </h2>
            <h2>Rent Per Day : <a>₹<?php echo $result['PRICE']?>/-</a></h2>
            <button type="submit"  name="booknow" class="button" style="margin-top: 5px;"><a href="booking.php?id=<?php echo $res;?>">book</a></button>
        </div>
    </div></form></li>
    <?php
        }
    
    ?>
    <?php 
    require_once('connection.php');
        

    $value = $_SESSION['email'];
    
    $sql="select * from users where EMAIL='$value'";
    $name = mysqli_query($con,$sql);
    $rows=mysqli_fetch_assoc($name);
    ?>
    </ul>
    </div>
  </div>
  </div>     
</body>
</html>