<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Page</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-image: url("images/lapbg1.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            height: 100vh;
            overflow: hidden;
        }
        .home-btn {
            position: absolute;
            top: 20px;
            font-size:20px;
            left: 20px;
            background-color: #ff7200;
            color: black;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
        }

        .blur-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            filter: blur(20px);
            z-index: -1;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form {
            width: 300px;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            padding: 20px;
        }

        .form h2 {
            text-align: center;
            color: black;
            font-size: 22px;
            margin-bottom: 20px;
        }

        .form input[type="text"],
        .form input[type="password"],
        .form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .form input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #ff7200;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            color: #fff;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .form input[type="submit"]:hover {
            background-color: #ff9f1a;
        }
    </style>
</head>
<body>
<a href="index.php" class="home-btn">Home</a>
    <div class="blur-background"></div>

    <div class="container">
        <form class="form" method="POST">
            <h2>Service Request</h2>
            <input type="text" required="required" id = "username" name="name" placeholder="Your Name">
            <input type="text" required="required" id = "mail" name="email" placeholder="Your Email">
            <textarea name="message" required="required"id="msg" placeholder="Your Message"></textarea>
            <input type="submit" value="Submit" name="submit" onclick="validateForm()"> 
            <!-- <input type="button" value="af" onclick=""> </input> -->
        </form>
    </div>

    <?php
       
    ?>
</body>
<script>
   
        function validateForm() {
            
            var name = document.getElementById("username").value;
            var email = document.getElementById("mail").value;
            var message = document.getElementById("msg").value;

            // Check if name field is empty
            if (name.trim() === "") {
                alert("Please enter your name.");
                return false;
            }
                // alert(name,email,message);
            // Check if email field is empty and if it is a valid email format
            if (email.trim() === "") {
                alert("Please enter your email address.");
                return false;
            } else if (!validateEmail(email)) {
                alert("Please enter a valid email address.");
                return false;
            }

            // Check if message field is empty
            if (message.trim() === "") {
                alert("Please enter your message.");
                return false;
            }
                alert("Service request submitted!");
            return true; // Form will be submitted if all validations pass

        }

        // Function to validate email format
        function validateEmail(email) {
            var re = /\S+@\S+\.\S+/;
            return re.test(email);
        }
    </script>
</html>
