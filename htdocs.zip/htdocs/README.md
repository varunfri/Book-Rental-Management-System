# laptop_rental
A Database project of a laptop rental management system
For admin login use:
Username: ADMIN
password: ADMIN